export const school = {
  name: 'Aga Khan Higher Secondary School', shortName: 'AKHSS', city: 'Hyderabad',
  address: 'Gulistan-e-Fatima, Near Mubarak Colony, Hyderabad, Pakistan',
  telephone: '+92 22 2619275', phoneLink: '+92222619275',
  source: 'https://www.agakhanschools.org/Pakistan/AKHSSH/Index',
  contact: 'https://www.agakhanschools.org/ContactUs/AKHSSH',
  instagram: null, whatsapp: null,
};
export const event = {
  id: 'qawwali-night-2026', title: 'Qawwali Night', date: '2026-12-10',
  dateLabel: 'Thursday, 10 December 2026', time: null, currency: 'PKR',
  price: 1500, capacity: 100, venue: 'AKHSS, Hyderabad',
  status: 'published', category: 'General admission', image: '/assets/qawwali-night.png',
  registrationDeadline: null,
};
export const gallery = [
  {src:'/assets/campus.jpg', title:'Curiosity in the classroom', category:'Learning', alt:'Students studying a specimen in a science lesson at AKHSS Hyderabad', credit:'Aga Khan Schools — Hyderabad school page'},
  {src:'/assets/school-life.jpg', title:'Learning, together', category:'Campus life', alt:'Students reading together outdoors at AKHSS Hyderabad', credit:'Aga Khan Schools — Hyderabad school page'},
  {src:'/assets/learning.jpg', title:'A culture of learning', category:'Learning', alt:'Professional development photograph from the official Hyderabad school page', credit:'Aga Khan Schools — Hyderabad school page'},
  {src:'/assets/qawwali-night.png', title:'An evening to look forward to', category:'Events', alt:'AI-generated harmonium and tabla in a forest green setting with brass lanterns', credit:'AI-generated promotional artwork; not a photograph of a past event'},
];
export let allEvents = [event];
export function setEvents(list, selectedId) {
  allEvents = list;
  const selected = list.find(e=>e.id===selectedId) || list.find(e=>e.status==='published') || list[0];
  if(selected) Object.assign(event, selected);
}
export const money = (n) => new Intl.NumberFormat('en-PK', {style:'currency',currency:event.currency,maximumFractionDigits:0}).format(n);
export const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function availability(e, now = new Date()) {
  if (e.status === 'cancelled') return {label:'Cancelled',canRegister:false};
  if (e.status === 'draft') return {label:'Draft',canRegister:false};
  if (e.status === 'completed' || e.date < now.toISOString().slice(0,10)) return {label:'Completed',canRegister:false};
  if (e.registrationDeadline && new Date(e.registrationDeadline) <= now) return {label:'Registration closed',canRegister:false};
  if (e.status === 'sold-out' || e.remaining === 0) return {label:'Sold out',canRegister:false};
  if (e.status === 'preview') return {label:'Registration preview',canRegister:false};
  return {label:'Registration open',canRegister:true};
}

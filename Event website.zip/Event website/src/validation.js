// Shared browser/server validation. Never accepts client-supplied prices or payment status.
export function validateRegistration(input, expectedEvent = {id:'qawwali-night-2026',category:'General admission',capacity:100}) {
  const errors = {};
  const text = (v, max=120) => typeof v === 'string' && v.trim().length > 0 && v.trim().length <= max;
  if (!input || typeof input !== 'object') return {form:'Invalid registration.'};
  if (input.eventId !== expectedEvent.id) errors.eventId = 'Choose an available event.';
  if (input.category !== expectedEvent.category) errors.category = 'Choose a valid ticket category.';
  if (!Number.isInteger(input.quantity) || input.quantity < 1 || input.quantity > expectedEvent.capacity) errors.quantity = `Choose between 1 and ${expectedEvent.capacity} tickets.`;
  if (!Array.isArray(input.attendees) || input.attendees.length !== input.quantity) errors.attendees = 'Enter one attendee for every ticket.';
  else input.attendees.forEach((a,i) => {
    if (!text(a?.name)) errors[`name-${i}`] = 'Enter the attendee’s full name.';
    if (!['student','guest'].includes(a?.type)) errors[`type-${i}`] = 'Select student or external guest.';
    if (a?.type === 'student') {
      if (!text(a.className,40)) errors[`class-${i}`] = 'Enter the student’s class.';
      if (!text(a.studentId,60)) errors[`student-${i}`] = 'Enter the student ID.';
    }
    if (a && ('cnic' in a || 'guardianCnic' in a)) errors[`name-${i}`] = 'Government identity numbers are not collected for this event.';
  });
  if (!text(input.email,254) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.email)) errors.email = 'Enter a valid email address.';
  if (!text(input.phone,30) || !/^\+?[\d\s().-]{7,30}$/.test(input.phone) || input.phone.replace(/\D/g,'').length < 7 || input.phone.replace(/\D/g,'').length > 15) errors.phone = 'Enter a valid contact number, including country code.';
  for (const key of ['rules','privacy','refunds']) if (input[key] !== true) errors[key] = 'Please acknowledge this before continuing.';
  if ('cnic' in input) errors.form = 'CNIC collection is disabled.';
  return errors;
}

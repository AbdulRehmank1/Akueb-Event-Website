import http from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {randomBytes,createHash,pbkdf2Sync,timingSafeEqual} from 'node:crypto';
import {mkdirSync,readFileSync,existsSync} from 'node:fs';
import {resolve,extname,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {documentHTML,pages} from './views.js';
import {adminPage,checkoutPage} from './admin-views.js';
import {event as initialEvent,setEvents,escapeHTML as esc} from './content.js';
import {validateRegistration} from './validation.js';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const hash=s=>createHash('sha256').update(s).digest('hex');
const random=()=>randomBytes(32).toString('base64url');
const day=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Karachi',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
function passwordHash(password,salt){return pbkdf2Sync(password,salt,210000,32,'sha256').toString('hex');}
function equal(a,b){const aa=Buffer.from(a),bb=Buffer.from(b);return aa.length===bb.length&&timingSafeEqual(aa,bb);}
const cookie=(name,token,age=28800)=>`${name}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${age}`;
const cookies=req=>Object.fromEntries((req.headers.cookie||'').split(';').map(s=>s.trim().split('=')));
const csvCell=v=>`"${String(v??'').replace(/^[=+\-@\t\r]/,"'$&").replace(/"/g,'""')}"`;

export function createApplication({databasePath=resolve(root,'data','school.sqlite')}={}) {
  mkdirSync(dirname(databasePath),{recursive:true});
  const db=new DatabaseSync(databasePath);
  db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
  db.exec(`CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,data TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY CHECK(id=1),username TEXT NOT NULL,salt TEXT NOT NULL,password_hash TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,expires_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS registrations(id TEXT PRIMARY KEY,reference TEXT UNIQUE NOT NULL,event_id TEXT NOT NULL REFERENCES events(id),event_snapshot TEXT NOT NULL,quantity INTEGER NOT NULL CHECK(quantity>0),total INTEGER NOT NULL,email TEXT NOT NULL,phone TEXT NOT NULL,attendees TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'unpaid' CHECK(status IN ('unpaid','cancelled')),created_at TEXT NOT NULL,idempotency_key TEXT UNIQUE NOT NULL,fingerprint TEXT NOT NULL,access_hash TEXT NOT NULL,consent_version TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,name TEXT NOT NULL,email TEXT NOT NULL,message TEXT NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS rate_limits(key TEXT PRIMARY KEY,count INTEGER NOT NULL,reset_at INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS registration_event_status ON registrations(event_id,status);`);
  db.prepare('INSERT OR IGNORE INTO events(id,data) VALUES(?,?)').run(initialEvent.id,JSON.stringify({...initialEvent,status:'published'}));
  pages['/admin']={title:'School administration — AKHSS',render:adminPage};
  pages['/checkout']={title:'Unpaid registration — AKHSS',render:checkoutPage};
  function queryEvents(includeDraft=false){return db.prepare('SELECT data FROM events').all().map(r=>JSON.parse(r.data)).filter(e=>includeDraft||e.status!=='draft').map(e=>({...e,remaining:Math.max(0,e.capacity-Number(db.prepare("SELECT COALESCE(SUM(quantity),0) AS count FROM registrations WHERE event_id=? AND status='unpaid'").get(e.id).count))}));}
  function readEvent(id){const row=db.prepare('SELECT data FROM events WHERE id=?').get(id);return row?JSON.parse(row.data):null;}
  function rateLimit(key,max,window=900000){const now=Date.now();const row=db.prepare('SELECT count,reset_at FROM rate_limits WHERE key=?').get(key);if(!row||row.reset_at<now){db.prepare('INSERT OR REPLACE INTO rate_limits VALUES(?,1,?)').run(key,now+window);return true;}if(row.count>=max)return false;db.prepare('UPDATE rate_limits SET count=count+1 WHERE key=?').run(key);return true;}
  function authenticated(req){const token=cookies(req).akhss_admin;if(!token)return false;return !!db.prepare('SELECT token_hash FROM sessions WHERE token_hash=? AND expires_at>?').get(hash(token),Date.now());}
  function registrationRecord(r,details=true){const e=JSON.parse(r.event_snapshot);return {id:r.id,reference:r.reference,eventId:r.event_id,eventTitle:e.title,dateLabel:e.dateLabel,venue:e.venue,currency:e.currency,category:e.category,quantity:r.quantity,total:r.total,status:r.status,paymentStatus:'unpaid',createdAt:r.created_at,...(details?{email:r.email,phone:r.phone,attendees:JSON.parse(r.attendees)}:{})};}
  function json(res,status,data,headers={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8',...headers});res.end(JSON.stringify(data));}
  async function body(req){if(!String(req.headers['content-type']).startsWith('application/json'))throw Object.assign(new Error('Use JSON content.'),{status:415});let length=0,chunks=[];for await(const chunk of req){length+=chunk.length;if(length>65536)throw Object.assign(new Error('Request is too large.'),{status:413});chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString());}catch{throw Object.assign(new Error('Invalid JSON request.'),{status:400});}}
  const server=http.createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');res.setHeader('Cache-Control','no-store');
    res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' data: blob:; script-src 'self'; worker-src 'self' blob:; style-src 'self' 'unsafe-inline'; connect-src 'self' blob:; font-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'; object-src 'none'");
    try {
      const host=req.headers.host||'';if(!/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host))return json(res,403,{error:'This local server only accepts localhost requests.'});
      const origin=`http://${host}`,url=new URL(req.url,origin),path=url.pathname;
      if(path==='/admin'||path==='/admin.js'||path.startsWith('/api/admin/'))return json(res,404,{error:'This section has been removed.'});
      if(req.method!=='GET'&&req.method!=='HEAD'&&req.headers.origin!==origin)return json(res,403,{error:'This request must come from the website on this computer.'});
      if(path.startsWith('/api/admin/')&& !['/api/admin/status','/api/admin/setup','/api/admin/login'].includes(path)&&!authenticated(req))return json(res,401,{error:'Please sign in to the administrator account.'});
      const ip=req.socket.remoteAddress||'unknown';
      if(path==='/api/admin/status'&&req.method==='GET')return json(res,200,{setupRequired:!db.prepare('SELECT id FROM admins LIMIT 1').get(),authenticated:authenticated(req)});
      if(path==='/api/admin/setup'&&req.method==='POST'){
        if(db.prepare('SELECT id FROM admins LIMIT 1').get())return json(res,409,{error:'An administrator already exists. Please sign in.'});
        const b=await body(req);if(b.username!=='admin'||typeof b.password!=='string'||b.password.length<12||b.password.length>128)return json(res,400,{error:'Use username admin and a password of 12–128 characters.'});
        const salt=random(),pass=passwordHash(b.password,salt);db.prepare('INSERT INTO admins VALUES(1,?,?,?)').run('admin',salt,pass);
        const token=random();db.prepare('INSERT INTO sessions VALUES(?,?)').run(hash(token),Date.now()+8*3600000);return json(res,201,{ok:true},{'Set-Cookie':cookie('akhss_admin',token)});
      }
      if(path==='/api/admin/login'&&req.method==='POST'){
        if(!rateLimit(`login:${ip}`,12))return json(res,429,{error:'Too many sign-in attempts. Try again in 15 minutes.'});
        const b=await body(req),a=db.prepare('SELECT * FROM admins WHERE id=1').get();
        if(typeof b.password!=='string'||b.password.length>128)return json(res,401,{error:'Incorrect username or password.'});
        const actual=passwordHash(b.password,a?.salt||'dummy-salt-for-timing');if(!a||b.username!==a.username||!equal(actual,a.password_hash))return json(res,401,{error:'Incorrect username or password.'});
        const token=random();db.prepare('DELETE FROM sessions WHERE expires_at<?').run(Date.now());db.prepare('INSERT INTO sessions VALUES(?,?)').run(hash(token),Date.now()+8*3600000);return json(res,200,{ok:true},{'Set-Cookie':cookie('akhss_admin',token)});
      }
      if(path==='/api/admin/logout'&&req.method==='POST'){db.prepare('DELETE FROM sessions WHERE token_hash=?').run(hash(cookies(req).akhss_admin||''));return json(res,200,{ok:true},{'Set-Cookie':cookie('akhss_admin','',0)});}
      if(path==='/api/events'&&req.method==='GET')return json(res,200,{events:queryEvents()});
      if(path==='/api/registrations'&&req.method==='POST'){
        if(!rateLimit(`registration:${ip}`,30))return json(res,429,{error:'Too many registrations from this computer. Please try again later.'});
        const b=await body(req),e=readEvent(b.eventId);if(!e)return json(res,404,{error:'Event not found.'});
        const errors=validateRegistration(b,e);if(Object.keys(errors).length)return json(res,422,{error:'Please correct the registration details.',errors});
        if(typeof b.idempotencyKey!=='string'||!/^[\w-]{20,80}$/.test(b.idempotencyKey))return json(res,400,{error:'Invalid request identifier. Reload the registration page.'});
        const attendees=b.attendees.map(a=>({name:a.name.trim(),type:a.type,...(a.type==='student'?{className:a.className.trim(),studentId:a.studentId.trim()}:{})}));
        const normalized={eventId:b.eventId,quantity:b.quantity,attendees,email:b.email.trim(),phone:b.phone.trim()},fingerprint=hash(JSON.stringify(normalized));
        const duplicate=db.prepare('SELECT * FROM registrations WHERE idempotency_key=?').get(b.idempotencyKey);
        if(duplicate){if(duplicate.fingerprint!==fingerprint)return json(res,409,{error:'This submission has already been used for different details. Reload and try again.'});const access=random();db.prepare('UPDATE registrations SET access_hash=? WHERE id=?').run(hash(access),duplicate.id);return json(res,200,{reference:duplicate.reference,status:duplicate.status},{'Set-Cookie':cookie('akhss_registration',access,86400)});}
        if(e.status!=='published'||e.date<day()||(e.registrationDeadline&&Date.parse(e.registrationDeadline)<=Date.now()))return json(res,409,{error:'Registration is not open for this event.'});
        const access=random(),id=randomBytes(16).toString('hex'),reference='AKH-'+randomBytes(5).toString('hex').toUpperCase();
        db.exec('BEGIN IMMEDIATE');
        try{
          const used=Number(db.prepare("SELECT COALESCE(SUM(quantity),0) AS count FROM registrations WHERE event_id=? AND status='unpaid'").get(e.id).count);
          if(used+b.quantity>e.capacity){db.exec('ROLLBACK');return json(res,409,{error:`Only ${Math.max(0,e.capacity-used)} registration places remain. Please reduce the ticket quantity.`});}
          db.prepare('INSERT INTO registrations VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id,reference,e.id,JSON.stringify(e),b.quantity,Math.round(e.price*100)*b.quantity/100,b.email.trim(),b.phone.trim(),JSON.stringify(attendees),'unpaid',new Date().toISOString(),b.idempotencyKey,fingerprint,hash(access),'local-unpaid-v1');
          db.exec('COMMIT');
        }catch(error){try{db.exec('ROLLBACK');}catch{}throw error;}
        return json(res,201,{reference,status:'unpaid'},{'Set-Cookie':cookie('akhss_registration',access,86400)});
      }
      if(path==='/api/registration/current'&&req.method==='GET'){
        const token=cookies(req).akhss_registration;if(!token)return json(res,404,{error:'Complete registration on this browser first.'});
        const r=db.prepare('SELECT * FROM registrations WHERE access_hash=?').get(hash(token));if(!r)return json(res,404,{error:'The registration could not be found.'});return json(res,200,registrationRecord(r));
      }
      if(path==='/api/contact'&&req.method==='POST'){
        if(!rateLimit(`contact:${ip}`,10))return json(res,429,{error:'Too many messages. Please try again later.'});const b=await body(req);
        if(typeof b.name!=='string'||!b.name.trim()||b.name.length>120||typeof b.email!=='string'||b.email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(b.email)||typeof b.message!=='string'||!b.message.trim()||b.message.length>2000)return json(res,422,{error:'Enter a name, valid email and message of up to 2,000 characters.'});
        db.prepare('INSERT INTO messages VALUES(?,?,?,?,?)').run(randomBytes(16).toString('hex'),b.name.trim(),b.email.trim(),b.message.trim(),new Date().toISOString());return json(res,201,{saved:true,emailSent:false});
      }
      if(path==='/api/admin/overview'&&req.method==='GET'){
        const counts=db.prepare("SELECT COUNT(*) AS registrations,COALESCE(SUM(CASE WHEN status='unpaid' THEN quantity ELSE 0 END),0) AS attendees,COALESCE(SUM(CASE WHEN status='unpaid' THEN total ELSE 0 END),0) AS unpaidAmount,SUM(CASE WHEN status='cancelled' THEN 1 ELSE 0 END) AS cancelled FROM registrations").get();return json(res,200,{...counts,paidOrders:0,revenue:0,confirmedAttendees:0,events:queryEvents(true)});
      }
      if(path==='/api/admin/registrations'&&req.method==='GET'){
        const search=(url.searchParams.get('search')||'').slice(0,120).toLowerCase(),eventId=url.searchParams.get('event')||'',status=url.searchParams.get('status')||'';
        const rows=db.prepare('SELECT * FROM registrations ORDER BY created_at DESC').all().filter(r=>(!eventId||r.event_id===eventId)&&(!status||r.status===status)&&(!search||`${r.reference} ${r.email} ${r.phone} ${r.attendees}`.toLowerCase().includes(search)));return json(res,200,{registrations:rows.map(r=>registrationRecord(r))});
      }
      if(path==='/api/admin/export'&&req.method==='GET'){
        const eventId=url.searchParams.get('event')||'',status=url.searchParams.get('status')||'',search=(url.searchParams.get('search')||'').slice(0,120).toLowerCase();
        const rows=db.prepare('SELECT * FROM registrations ORDER BY created_at DESC').all().filter(r=>(!eventId||r.event_id===eventId)&&(!status||r.status===status)&&(!search||`${r.reference} ${r.email} ${r.phone} ${r.attendees}`.toLowerCase().includes(search)));
        const lines=[['Reference','Event','Attendee','Ticket category','Registration status','Payment status','Registered at']];for(const r of rows){const e=JSON.parse(r.event_snapshot);for(const a of JSON.parse(r.attendees))lines.push([r.reference,e.title,a.name,e.category,r.status,'unpaid',r.created_at]);}res.writeHead(200,{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="akhss-registrations.csv"'});return res.end('\uFEFF'+lines.map(l=>l.map(csvCell).join(',')).join('\r\n'));
      }
      if(path==='/api/admin/cancel'&&req.method==='POST'){const b=await body(req);const r=db.prepare("UPDATE registrations SET status='cancelled' WHERE id=?").run(b.id);return json(res,r.changes?200:404,r.changes?{ok:true}:{error:'Registration not found.'});}
      if(path==='/api/admin/delete-registration'&&req.method==='POST'){const b=await body(req);db.prepare('DELETE FROM registrations WHERE id=?').run(b.id);return json(res,200,{ok:true});}
      if(path==='/api/admin/messages'&&req.method==='GET')return json(res,200,{messages:db.prepare('SELECT * FROM messages ORDER BY created_at DESC').all()});
      if(path==='/api/admin/delete-message'&&req.method==='POST'){const b=await body(req);db.prepare('DELETE FROM messages WHERE id=?').run(b.id);return json(res,200,{ok:true});}
      if(path==='/api/admin/events'&&req.method==='GET')return json(res,200,{events:queryEvents(true)});
      if(path==='/api/admin/events'&&req.method==='POST'){
        const b=await body(req);const errors=[];if(!/^[a-z0-9-]{3,80}$/.test(b.id||''))errors.push('Use a lowercase event ID with letters, numbers and hyphens.');
        for(const k of ['title','venue','category'])if(typeof b[k]!=='string'||!b[k].trim()||b[k].length>160)errors.push(`Enter a valid ${k}.`);
        if(!/^\d{4}-\d{2}-\d{2}$/.test(b.date||'')||Number.isNaN(Date.parse(b.date))||new Date(b.date).toISOString().slice(0,10)!==b.date)errors.push('Enter a valid event date.');
        if(!Number.isFinite(b.price)||b.price<0||b.price>10000000||Math.round(b.price*100)!==b.price*100)errors.push('Enter a valid price with at most two decimals.');
        if(!Number.isInteger(b.capacity)||b.capacity<1||b.capacity>10000)errors.push('Capacity must be between 1 and 10,000.');
        if(!['draft','published','sold-out','cancelled','completed'].includes(b.status))errors.push('Choose a valid event status.');
        if(b.time&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(b.time))errors.push('Enter a valid start time.');
        if(b.registrationDeadline&&Number.isNaN(Date.parse(b.registrationDeadline)))errors.push('Enter a valid registration deadline.');
        if(errors.length)return json(res,422,{error:errors.join(' ')});
        const used=Number(db.prepare("SELECT COALESCE(SUM(quantity),0) AS count FROM registrations WHERE event_id=? AND status='unpaid'").get(b.id).count);if(b.capacity<used)return json(res,409,{error:`Capacity cannot be below the ${used} active attendee registrations.`});
        const e={id:b.id,title:b.title.trim(),date:b.date,dateLabel:new Intl.DateTimeFormat('en-GB',{dateStyle:'full',timeZone:'Asia/Karachi'}).format(new Date(b.date+'T12:00:00+05:00')),time:b.time||null,venue:b.venue.trim(),price:b.price,capacity:b.capacity,status:b.status,currency:'PKR',category:b.category.trim(),image:'/assets/qawwali-night.png',registrationDeadline:b.registrationDeadline||null};db.prepare('INSERT INTO events(id,data) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data').run(e.id,JSON.stringify(e));return json(res,200,{event:e});
      }
      if(path.startsWith('/api/'))return json(res,404,{error:'Endpoint not found.'});
      if(req.method!=='GET'&&req.method!=='HEAD')return json(res,405,{error:'Method not allowed.'});
      const modulePaths={'/content.js':'src/content.js','/views.js':'src/views.js','/validation.js':'src/validation.js'};
      const file=modulePaths[path]?resolve(root,modulePaths[path]):resolve(root,'public','.'+path);
      const assetPath=path.startsWith('/assets/')||['/styles.css','/theme.js','/app.js','/admin.js'].includes(path)||modulePaths[path];
      if(assetPath){const allowedRoot=modulePaths[path]?resolve(root,'src'):resolve(root,'public');if(!file.startsWith(allowedRoot)||!existsSync(file))return json(res,404,{error:'Asset not found.'});const types={'.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.ttf':'font/ttf','.wasm':'application/wasm'};const data=readFileSync(file);res.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream','Content-Length':data.length,'Cache-Control':'no-cache'});return res.end(req.method==='HEAD'?undefined:data);}
      const sectionRoutes={'/about':'about','/events':'events','/events/qawwali-night':'event-details','/register':'register','/gallery':'gallery','/contact':'contact','/policies':'policies','/preview':'site-info','/credits':'credits'};if(sectionRoutes[path]){res.writeHead(302,{Location:'/'+url.search+'#'+sectionRoutes[path]});return res.end();}
      const list=queryEvents();const selectedId=url.searchParams.get('event')||'qawwali-night-2026';setEvents(list,selectedId);
      let html=documentHTML(path);
      html=html.replace('</head>',`<script id="page-context" type="application/json">${JSON.stringify({events:list,selectedEvent:selectedId}).replace(/</g,'\\u003c')}</script></head>`);
      res.writeHead(pages[path]?200:404,{'Content-Type':'text/html; charset=utf-8'});res.end(req.method==='HEAD'?undefined:html);
    }catch(error){json(res,error.status||500,{error:error.status?error.message:'The request could not be completed. Please try again.'});}
  });
  return {server,db,close:()=>new Promise(resolveClose=>server.close(()=>{db.close();resolveClose();}))};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const port=Number(process.env.PORT||4173);const app=createApplication();app.server.listen(port,'127.0.0.1',()=>console.log(`AKHSS website: http://127.0.0.1:${port}\nAdmin: http://127.0.0.1:${port}/admin\nLocal server only. Press Ctrl+C to stop.`));
  process.on('SIGINT',()=>app.close().then(()=>process.exit(0)));process.on('SIGTERM',()=>app.close().then(()=>process.exit(0)));
}

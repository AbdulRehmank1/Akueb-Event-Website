@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22.13 or newer is required. Install Node.js from https://nodejs.org/
  pause
  exit /b 1
)
echo Starting the AKHSS website...
echo Website: http://127.0.0.1:4173
echo Admin:   http://127.0.0.1:4173/admin
echo Keep this window open while using the website. Press Ctrl+C to stop.
node src\server.mjs
pause

# AKHSS Hyderabad — local event website

The working website is saved in **E:\Event website**. It is a standalone Node.js application with SQLite storage. No Shopify account, hosting subscription, npm install or external database is required.

## Open the website

1. Double-click `START-WEBSITE.cmd` in `E:\Event website`.
2. Open <http://127.0.0.1:4173>.
3. Keep the server window open. Press Ctrl+C in that window to stop it.

If the site is already running, just open the URL; do not start a second copy on the same port.

Node.js 22.13 or newer is required (tested using Node.js 26.13). Alternatively, run `npm start` in the website folder.

## Administrator access

Open <http://127.0.0.1:4173/admin>. On first use, choose a password of at least 12 characters for the **admin** username. There is no default password, and no administrator has been created in your real database.

After signing in, you can:

- See saved registration records and separate attendee details.
- Search by attendee, reference, email or phone and filter by event/status.
- Export a CSV with names and registration details; email, phone and student identifiers are excluded.
- View and change event date, time, venue, price, ticket category, capacity, deadline and publication status.
- Create additional events using the current event artwork/layout.
- Cancel unpaid registrations and release their capacity.
- Permanently delete registration personal data and contact messages.
- Read messages submitted through the contact form.

## Registration & checkout behavior

The initial event is **Qawwali Night**, **10 December 2026**, **PKR 1,500 per person**, **100 attendees**, at **AKHSS Hyderabad**. Start time is still to be confirmed.

Visitors choose a quantity, enter separate attendee names and student/guest details, enter the booking contact email and telephone, review the information, then click **Save & continue**. This saves the record in SQLite and opens the non-working checkout.

**All registrations remain unpaid.** The payment button is disabled. There are no card fields, charges, paid tickets or payment-confirmation claims. Active unpaid registrations count toward capacity; cancelled or deleted registrations release capacity. Totals are calculated on the server from the saved event price. Duplicate submission retries do not create duplicate records.

The checkout summary is only available to the browser that saved the registration, through an HTTP-only cookie. No attendee information is placed in URLs or browser local storage. Theme preference is the only local-storage value.

The contact form saves messages for the administrator. It does **not** send email and says so on screen.

## Storage & backups

The database is `data\school.sqlite` inside the website folder. SQLite may also use `school.sqlite-wal` and `school.sqlite-shm` while running. The database contains contact details, attendee information and password hashes. Keep the folder private to the administrator’s Windows account.

To back up: stop the server cleanly, then copy the entire `data` folder to a secure location. To restore: stop the server and replace the `data` folder with a backup. Do not overwrite this folder when updating source files.

The administrator password is salted and hashed with PBKDF2-SHA256 (210,000 iterations). Session tokens are stored as hashes, expire after eight hours and are revoked at sign-out. The app uses same-origin checks, HTTP-only SameSite cookies, parameterized SQL, request limits, sign-in throttling and server-side authorization for all record access and CSV exports.

CNIC is not collected or accepted. Delete registrations from the detail view when no longer needed. A 90-day post-event retention period is suggested in the privacy notice; deletion is manual, not automatic.

## Local access

The server listens on **127.0.0.1 only** and accepts localhost hostnames. People on other computers cannot access it yet. This is intentional for the requested local installation. Public deployment would require HTTPS, a supported persistent server/database, secure cookies, a defined administrator identity and appropriate operational review. This version is not configured for a public internet deployment.

## Design & assets

The site includes Home, About, Events, event detail, Registration, Checkout, Gallery, Contact, policies, image credits and an authenticated Admin area. It uses deep green, white and mint with a matching dark mode, mobile navigation, native page transitions, section reveals, a short desktop pinned storytelling section, hover effects and a book-style saving indicator. Reduced motion disables animation and pinning. Mobile uses normal scrolling.

School information, photographs and the wordmark came from the official [Hyderabad school page](https://www.agakhanschools.org/Pakistan/AKHSSH/Index). Facility descriptions came from the official [facilities page](https://www.agakhanschools.org/Pakistan/AKHSSH/Facilities/Index). Asset URLs and rights notes are in `ASSET-CREDITS.md`. The Qawwali banner was generated specifically for this project using the built-in image-generation tool; the full prompt is in `IMAGE-PROMPT.md`.

School imagery remains owned by the relevant rights holders; public reuse rights have not been verified. Confirm approved school assets before publishing online. The header book icon is an original temporary interface mark; the official Aga Khan Schools wordmark appears in the footer.

Instagram and WhatsApp destinations remain visibly unconfigured. Mission wording is marked as editorial preview copy. The event programme and time are not invented.

## Verification

Run `npm test` for the isolated automated suite. Test data is stored in a separate temporary database and removed after a successful run.

Verified: public routes/assets, unauthenticated admin rejection, cross-origin write rejection, one-time admin setup, password hashing, student/acknowledgement validation, CNIC rejection, server-priced unpaid registration, duplicate protection, private checkout access, concurrent capacity checks, cancellation releasing capacity, persisted contact messages, privacy-conscious CSV, zero payment/revenue metrics, database restart persistence, logout and login.

Browser checks covered the complete two-attendee form → review → saved unpaid checkout → admin records flow, student fields, inline errors, 390-pixel mobile layout, menu, dark-mode persistence and record detail/capacity views. Browser tests used a separate database; no test registrations or test administrator are in the delivered database.

## Files

- `src/server.mjs`: HTTP server, SQLite database, admin authorization and APIs.
- `src/views.js`: server-rendered page composition.
- `src/content.js`: school information and initial event defaults.
- `src/validation.js`: shared validation used by browser and server.
- `public/styles.css`: responsive layout, theme and motion.
- `public/app.js`: registration, gallery, theme and page interactions.
- `public/admin.js`: authenticated administration interface.
- `public/assets/`: local school photographs, logo and event artwork.
- `tests/server.test.mjs`: isolated integration tests.

Existing database event values take precedence over initial source defaults. Use the Admin area to change live local event details.

## Neo design update

The public website is a single page: navigation scrolls between sections without a page reload. The admin area remains separate and protected. The design uses locally hosted Geist, the supplied Moncy portfolio character, a lavender cursor, mouse-responsive head movement, an intro animation, pinned hero and horizontal school story. Reduced-motion and touch layouts are supported. School images, contact information and registration storage are retained.

The site owner confirmed permission to reuse the exact portfolio design and proprietary character on 11 November 2026. Original license and attribution are preserved; this is not a grant of unrestricted redistribution rights. Three.js is distributed under MIT and Geist under OFL; notices are included in the asset folders.

## Latest revision — 11 November 2026
The admin interface and all admin endpoints are now disabled (404), superseding the earlier administrator instructions. Existing data is preserved. Registration still stores unpaid entries locally. Added Lenis 1.3.27 smooth scrolling, same-page Registration navigation, outlined cursor, floating header, circular theme reveal and refresh intro. School information is paraphrased from the official AKHSS Hyderabad website. Motion references are adaptations, not exact replicas.


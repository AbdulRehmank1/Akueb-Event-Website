try{const saved=localStorage.getItem('akhss-theme');document.documentElement.dataset.theme=saved==='dark'||saved==='light'?saved:'dark';}catch{document.documentElement.dataset.theme='dark';}

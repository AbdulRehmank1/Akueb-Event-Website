# Asset sources

Retrieved 11 November 2026 for the requested local school website.

| File | Source | Usage note |
| --- | --- | --- |
| public/assets/campus.jpg | https://www.agakhanschools.org/Content/img/AKHSSH/home_banner.jpg | Official Hyderabad school science-learning photo; filename is local only, not a claim of an exterior campus photograph. |
| public/assets/school-life.jpg | https://www.agakhanschools.org/Content/img/AKHSSH/about.jpg | Official school photo of students outdoors. |
| public/assets/learning.jpg | https://www.agakhanschools.org/Content/img/AKHSSH/professional_development.jpg | Official professional development photograph. |
| public/assets/school-logo.png | https://www.agakhanschools.org/Content/img/akes_top_logo_school_phone.png | Official Aga Khan Schools wordmark, displayed without redrawing it. |
| public/assets/qawwali-night.png | Generated for this project with OpenAI’s built-in image tool | Promotional concept artwork; not an image of an actual past event. |
| public/assets/favicon.svg | Original code-native book symbol | Temporary interface mark, not an official school crest. |

School photographs and wordmark remain the property of their respective rights holders. Public reuse rights have not been verified. The site links to its official source and identifies the AI-generated artwork.

## Portfolio design reference and 3D character

Moncy Yohannan / Moncy Dev: supplied Portfolio-Website-main.zip. The site owner explicitly confirmed permission for the exact design and character on 11 November 2026. Original license: public/assets/models/MONCY-LICENSE.txt. Character and HDR environment remain subject to that permission. Geist is locally hosted (OFL); Three.js 0.168.0 and loaders (MIT) retain their license notices.

Character update: current Moncy.dev model downloaded from its public /models/character.enc asset on 12 November 2026, under the site owner's previously confirmed permission. Stored as character-current.enc; attribution retained.

